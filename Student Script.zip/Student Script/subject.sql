USE [JWTAuthCoredb]
GO

INSERT INTO [dbo].[Subject]([SubjectName])VALUES('SCIENCE')
INSERT INTO [dbo].[Subject]([SubjectName])VALUES('GUJARATI')
INSERT INTO [dbo].[Subject]([SubjectName])VALUES('S.S.')
INSERT INTO [dbo].[Subject]([SubjectName])VALUES('MATHS')
INSERT INTO [dbo].[Subject]([SubjectName])VALUES('ENGLISH')
INSERT INTO [dbo].[Subject]([SubjectName])VALUES('SANSKRIT')
INSERT INTO [dbo].[Subject]([SubjectName])VALUES('HINDI')
INSERT INTO [dbo].[Subject]([SubjectName])VALUES('APPAREL')
INSERT INTO [dbo].[Subject]([SubjectName])VALUES('AUTOMOTIVE')

GO


