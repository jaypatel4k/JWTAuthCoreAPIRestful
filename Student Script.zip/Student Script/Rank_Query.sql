
select K.[Name], K.RollNo , K.Total, K.RANK1 FROM
(
select T.[Name], T.RollNo , T.Total, RANK() OVER(ORDER BY T.Total DESC) AS [RANK1] 
FROM
(select S.[Name], S.RollNo , SUM(M.Marks ) Total
from Student S inner join StudentMark M on S.Id = M.StudentId
inner join [Subject] sub on sub.Id = M.SubjectId
WHERE M.DivisionId =1 and M.StandardId=10 and M.MonthId = 12 and M.StreamId= 1 
and M.TestHeldOfMarkId = 1 AND M.TestTypeId =1 AND M.YearId = 1
GROUP BY S.[Name], S.RollNo
) AS T
) K
WHERE K.RANK1 < 4

select K.[Name], K.RollNo, K.SubjectName , K.Total ,K.[RANK1] from
(select T.[Name], T.RollNo, T.SubjectName , T.Total ,RANK() OVER(PARTITION BY T.SubjectName ORDER BY T.Total DESC) AS [RANK1]
FROM
(select S.[Name], S.RollNo, sub.SubjectName , MAX(M.Marks ) Total
from Student S inner join StudentMark M on S.Id = M.StudentId
inner join [Subject] sub on sub.Id = M.SubjectId
WHERE M.DivisionId =1 and M.StandardId=10 and M.MonthId = 12 and M.StreamId= 1 and M.TestHeldOfMarkId = 1 AND M.TestTypeId =1 AND M.YearId = 1
GROUP BY S.[Name], S.RollNo,sub.SubjectName
) AS T
)K
WHERE K.RANK1 < 2
ORDER BY K.SubjectName,K.RANK1
