USE [JWTAuthCoredb]
GO

INSERT INTO [dbo].[StreamType] ([StreamName]) VALUES('SCIENCE')
INSERT INTO [dbo].[StreamType] ([StreamName]) VALUES('COMMERCE')
INSERT INTO [dbo].[StreamType] ([StreamName]) VALUES('ARTS')
GO


