USE [StudentDB]
GO

INSERT INTO [dbo].[Division]([DivisionName])VALUES('A')
INSERT INTO [dbo].[Division]([DivisionName])VALUES('B')
INSERT INTO [dbo].[Division]([DivisionName])VALUES('C')
INSERT INTO [dbo].[Division]([DivisionName])VALUES('D')
INSERT INTO [dbo].[Division]([DivisionName])VALUES('E')
INSERT INTO [dbo].[Division]([DivisionName])VALUES('F')

GO


