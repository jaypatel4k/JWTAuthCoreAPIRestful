USE [StudentDB]
GO

INSERT INTO [dbo].[TestHeldOfMark]
           ([TestTypeId]
           ,[OutOfMark])
     VALUES
           (1
           ,25)
GO


