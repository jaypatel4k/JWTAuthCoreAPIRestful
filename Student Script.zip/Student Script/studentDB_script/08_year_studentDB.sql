USE [StudentDB]
GO

INSERT INTO [dbo].[Year]([year]) VALUES('2024')
INSERT INTO [dbo].[Year]([year]) VALUES('2025')
INSERT INTO [dbo].[Year]([year]) VALUES('2026')
INSERT INTO [dbo].[Year]([year]) VALUES('2027')
INSERT INTO [dbo].[Year]([year]) VALUES('2028')
INSERT INTO [dbo].[Year]([year]) VALUES('2029')
INSERT INTO [dbo].[Year]([year]) VALUES('2030')
INSERT INTO [dbo].[Year]([year]) VALUES('2031')
INSERT INTO [dbo].[Year]([year]) VALUES('2032')
INSERT INTO [dbo].[Year]([year]) VALUES('2033')
INSERT INTO [dbo].[Year]([year]) VALUES('2034')
INSERT INTO [dbo].[Year]([year]) VALUES('2035')
INSERT INTO [dbo].[Year]([year]) VALUES('2036')
INSERT INTO [dbo].[Year]([year]) VALUES('2037')
INSERT INTO [dbo].[Year]([year]) VALUES('2038')
INSERT INTO [dbo].[Year]([year]) VALUES('2039')
INSERT INTO [dbo].[Year]([year]) VALUES('2040')

GO


