USE StudentDB
GO

INSERT INTO [dbo].[Standard] ([StandardName]) VALUES('I')
INSERT INTO [dbo].[Standard] ([StandardName]) VALUES('II')
INSERT INTO [dbo].[Standard] ([StandardName]) VALUES('III')
INSERT INTO [dbo].[Standard] ([StandardName]) VALUES('IV')
INSERT INTO [dbo].[Standard] ([StandardName]) VALUES('V')
INSERT INTO [dbo].[Standard] ([StandardName]) VALUES('VI')
INSERT INTO [dbo].[Standard] ([StandardName]) VALUES('VII')
INSERT INTO [dbo].[Standard] ([StandardName]) VALUES('VIII')
INSERT INTO [dbo].[Standard] ([StandardName]) VALUES('IX')
INSERT INTO [dbo].[Standard] ([StandardName]) VALUES('X')
INSERT INTO [dbo].[Standard] ([StandardName]) VALUES('XI')
INSERT INTO [dbo].[Standard] ([StandardName]) VALUES('XII')
GO


