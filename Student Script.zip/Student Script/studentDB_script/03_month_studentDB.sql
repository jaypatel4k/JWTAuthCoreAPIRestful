USE [StudentDB]
GO

INSERT INTO [dbo].[Month]([MonthName])VALUES('January')
INSERT INTO [dbo].[Month]([MonthName])VALUES('February')
INSERT INTO [dbo].[Month]([MonthName])VALUES('March')
INSERT INTO [dbo].[Month]([MonthName])VALUES('April')
INSERT INTO [dbo].[Month]([MonthName])VALUES('May')
INSERT INTO [dbo].[Month]([MonthName])VALUES('June')
INSERT INTO [dbo].[Month]([MonthName])VALUES('July')
INSERT INTO [dbo].[Month]([MonthName])VALUES('August')
INSERT INTO [dbo].[Month]([MonthName])VALUES('September')
INSERT INTO [dbo].[Month]([MonthName])VALUES('October')
INSERT INTO [dbo].[Month]([MonthName])VALUES('November')
INSERT INTO [dbo].[Month]([MonthName])VALUES('December')


