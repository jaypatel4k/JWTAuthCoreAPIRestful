USE [StudentDB]
GO

INSERT INTO [dbo].[TestType]
           ([TestTypeName])
     VALUES
           ('UNIT TEST')
GO


