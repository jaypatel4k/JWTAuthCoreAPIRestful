USE [JWTAuthCoredb]
GO

INSERT INTO [dbo].[Year]([year]) VALUES('2024')
INSERT INTO [dbo].[Year]([year]) VALUES('2025')
INSERT INTO [dbo].[Year]([year]) VALUES('2026')
INSERT INTO [dbo].[Year]([year]) VALUES('2027')
INSERT INTO [dbo].[Year]([year]) VALUES('2028')
INSERT INTO [dbo].[Year]([year]) VALUES('2029')
INSERT INTO [dbo].[Year]([year]) VALUES('2030')
INSERT INTO [dbo].[Year]([year]) VALUES('2031')
INSERT INTO [dbo].[Year]([year]) VALUES('2032')
GO


